import React from 'react';
import type { Team } from '../types';

interface TeamSelectorProps {
  teams: Team[];
  onSelect: (team: Team) => void;
}

const TeamSelector: React.FC<TeamSelectorProps> = ({ teams, onSelect }) => {
  return (
    <div className="w-full">
      <h2 className="text-2xl font-semibold text-center mb-8 text-slate-200">Select Your Team to Begin</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teams.map((team) => {
          const IconComponent = team.icon;
          return (
            <button
              key={team.id}
              onClick={() => onSelect(team)}
              className={`bg-slate-800 p-6 rounded-xl shadow-lg cursor-pointer transition-all duration-300 ease-in-out hover:shadow-2xl hover:-translate-y-2 border-b-4 border-transparent text-left ${team.hoverColor}`}
            >
              <div className="flex items-center gap-4 mb-3">
                <div className={`p-3 rounded-lg ${team.color}`}>
                  <IconComponent className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold text-slate-50">{team.name}</h3>
              </div>
              <p className="text-slate-400 text-sm">{team.description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default TeamSelector;
