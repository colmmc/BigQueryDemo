import React from 'react';
import { DatabaseIcon } from './icons';

const Header = () => {
  return (
    <header className="w-full max-w-4xl mx-auto py-8 text-center">
      <div className="flex items-center justify-center gap-4">
        <DatabaseIcon className="w-10 h-10 text-sky-400" />
        <div>
          <h1 className="text-4xl font-bold text-slate-50 tracking-tight">Team Report Uploader</h1>
          <p className="text-slate-400 mt-1">Upload weekly CSV files to update BigQuery tables</p>
        </div>
      </div>
    </header>
  );
};

export default Header;