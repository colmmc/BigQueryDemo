import React, { useState } from 'react';

interface PasswordProtectProps {
  onAuthenticated: (isAuthenticated: boolean) => void;
}

// NOTE: This is a simple, hardcoded password for demonstration purposes.
// For a production environment, use a proper authentication service.
const PASSWORD = 'BigQuery2024!';

const PasswordProtect: React.FC<PasswordProtectProps> = ({ onAuthenticated }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === PASSWORD) {
      setError('');
      onAuthenticated(true);
    } else {
      setError('Incorrect password. Please try again.');
      setPassword('');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-95 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in">
      <div className="w-full max-w-sm bg-slate-800 p-8 rounded-xl shadow-2xl border border-slate-700">
        <h2 className="text-2xl font-bold text-center text-slate-100 mb-2">Access Protected</h2>
        <p className="text-center text-slate-400 mb-6">This application requires a password for access.</p>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label htmlFor="password-input" className="sr-only">Password</label>
            <input
              id="password-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              className="w-full px-4 py-2 bg-slate-700 border border-slate-600 rounded-lg text-slate-100 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 outline-none transition"
              autoFocus
            />
          </div>
          {error && <p className="text-rose-400 text-sm text-center -my-2">{error}</p>}
          <button
            type="submit"
            className="w-full bg-sky-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-sky-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!password}
          >
            Enter
          </button>
        </form>
      </div>
    </div>
  );
};

export default PasswordProtect;
