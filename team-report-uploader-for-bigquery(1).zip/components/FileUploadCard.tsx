import React, { useState, useCallback, useRef } from 'react';
import type { Team } from '../types';
import { UploadStatus } from '../types';
import { ArrowLeftIcon, UploadIcon, FileIcon, CheckCircleIcon, XCircleIcon } from './icons';

interface FileUploadCardProps {
  team: Team;
  onBack: () => void;
}

const FileUploadCard: React.FC<FileUploadCardProps> = ({ team, onBack }) => {
  const [status, setStatus] = useState<UploadStatus>(UploadStatus.IDLE);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvRows, setCsvRows] = useState<string[][]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (selectedFile: File | null) => {
    if (selectedFile) {
      if (selectedFile.type === 'text/csv' || selectedFile.name.endsWith('.csv')) {
        setFile(selectedFile);
        setStatus(UploadStatus.FILE_SELECTED);
        setError(null);

        try {
          const content = await selectedFile.text();
          const lines = content.split('\n').filter(line => line.trim() !== '');
          if (lines.length > 0) {
            const headers = lines[0].split(',').map(h => h.trim());
            const rows = lines.slice(1, 6).map(line => line.split(',').map(cell => cell.trim()));
            setCsvHeaders(headers);
            setCsvRows(rows);
          }
        } catch (e) {
            console.error("Error reading or parsing file:", e);
            setError("Could not read the file. Please ensure it is a valid CSV.");
            setStatus(UploadStatus.ERROR);
            setFile(null);
        }
      } else {
        setError('Invalid file type. Please upload a .csv file.');
        setStatus(UploadStatus.ERROR);
        setFile(null);
      }
    }
  };

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    setStatus(UploadStatus.DRAGGING);
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    setStatus(file ? UploadStatus.FILE_SELECTED : UploadStatus.IDLE);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };
  
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelect(e.target.files[0]);
    }
  };

  const handleUpload = useCallback(async () => {
    if (!file) return;

    setStatus(UploadStatus.UPLOADING);
    setError(null);
    
    // In a real application, you would send the 'file' object to your backend server here.
    // The backend would handle authentication with Google Cloud and stream the data into BigQuery.
    // This frontend should not contain any GCP credentials or connect to BigQuery directly.
    console.log("Simulating file upload to backend for team:", team.id);
    await new Promise(resolve => setTimeout(resolve, 2500));

    // Simulate success/error for demonstration
    if (Math.random() > 0.15) { // 85% success rate
      setStatus(UploadStatus.SUCCESS);
    } else {
      setStatus(UploadStatus.ERROR);
      setError("An unexpected error occurred during upload. Please try again.");
    }
  }, [file, team.id]);
  
  const resetState = () => {
    setFile(null);
    setStatus(UploadStatus.IDLE);
    setError(null);
    setCsvHeaders([]);
    setCsvRows([]);
    if(fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const renderContent = () => {
    switch (status) {
      case UploadStatus.UPLOADING:
        return (
          <div className="text-center">
            <div role="status" className="flex justify-center items-center">
                <svg aria-hidden="true" className="w-12 h-12 text-slate-600 animate-spin fill-sky-500" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="currentColor"/>
                    <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0492C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" />
                </svg>
            </div>
            <p className="mt-4 text-slate-300 font-semibold">Uploading {file?.name}...</p>
            <p className="text-sm text-slate-400">Please wait while we process your file.</p>
          </div>
        );
      case UploadStatus.SUCCESS:
        return (
          <div className="text-center">
            <CheckCircleIcon className="w-16 h-16 text-emerald-500 mx-auto"/>
            <h3 className="text-2xl font-bold text-slate-50 mt-4">Upload Successful!</h3>
            <p className="text-slate-400 mt-1">Your report has been submitted and is now being processed.</p>
            <button onClick={resetState} className="mt-6 bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors">
              Upload Another File
            </button>
          </div>
        );
      case UploadStatus.ERROR:
        return (
          <div className="text-center">
            <XCircleIcon className="w-16 h-16 text-rose-500 mx-auto"/>
            <h3 className="text-2xl font-bold text-slate-50 mt-4">Upload Failed</h3>
            <p className="text-rose-400 mt-1">{error}</p>
            <button onClick={resetState} className="mt-6 bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors">
              Try Again
            </button>
          </div>
        );
      default:
        return (
          <>
            <div 
              onDragEnter={handleDragEnter} 
              onDragLeave={handleDragLeave} 
              onDragOver={handleDragOver} 
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`relative flex flex-col items-center justify-center p-8 border-2 border-dashed rounded-lg cursor-pointer transition-colors duration-300 ${isDragging ? 'border-sky-500 bg-sky-500/10' : 'border-slate-600 hover:border-sky-500 hover:bg-slate-700/50'}`}
            >
              <input type="file" ref={fileInputRef} onChange={handleFileInputChange} accept=".csv" className="hidden" />
              <UploadIcon className={`transition-colors duration-300 ${isDragging ? 'text-sky-400' : 'text-slate-500'}`} />
              <p className="mt-2 font-semibold text-slate-300">
                {isDragging ? 'Drop your CSV file here' : 'Drag & drop a file or click to browse'}
              </p>
              <p className="text-xs text-slate-500">Only .csv files are accepted</p>
            </div>
            {file && (
              <div className="mt-4 bg-slate-700/50 p-3 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileIcon className="w-8 h-8 text-sky-400 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-slate-200 truncate">{file.name}</p>
                    <p className="text-xs text-slate-400">{(file.size / 1024).toFixed(2)} KB</p>
                  </div>
                </div>
                <button onClick={() => resetState()} className="text-slate-500 hover:text-rose-400 transition-colors">
                  <XCircleIcon className="w-6 h-6" />
                </button>
              </div>
            )}
          </>
        );
    }
  };

  const IconComponent = team.icon;

  return (
    <div className="bg-slate-800 rounded-xl shadow-2xl p-8 w-full max-w-2xl animate-fade-in">
        <div className="flex items-start justify-between mb-6">
            <div>
                <button onClick={onBack} className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-200 transition-colors mb-2">
                    <ArrowLeftIcon />
                    Back to team selection
                </button>
                <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${team.color}`}>
                        <IconComponent className='w-7 h-7' />
                    </div>
                    <h2 className="text-3xl font-bold text-slate-50">{team.name} Report Upload</h2>
                </div>
            </div>
        </div>

        <div className="mb-6 bg-slate-900/50 p-4 rounded-lg">
            <h4 className="font-semibold text-slate-200 mb-2">Expected CSV Columns:</h4>
            <div className="flex flex-wrap gap-2">
                {team.expectedColumns.map(col => (
                    <code key={col} className="text-xs bg-slate-700 text-slate-300 py-1 px-2 rounded">{col}</code>
                ))}
            </div>
        </div>

        <div className="min-h-[200px] flex flex-col justify-center">
          {renderContent()}
        </div>

        {status === UploadStatus.FILE_SELECTED && csvHeaders.length > 0 && (
            <div className="mt-6 animate-fade-in">
                <h4 className="font-semibold text-slate-200 mb-2">File Preview (first {csvRows.length} data rows)</h4>
                <div className="overflow-x-auto rounded-lg border border-slate-700 bg-slate-900/50">
                    <table className="w-full text-sm text-left text-slate-300">
                        <thead className="text-xs text-slate-300 uppercase bg-slate-700/50">
                            <tr>
                                {csvHeaders.map((header, index) => (
                                    <th key={index} scope="col" className="px-4 py-3 whitespace-nowrap">
                                        {header}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {csvRows.map((row, rowIndex) => (
                                <tr key={rowIndex} className="border-b border-slate-700 last:border-b-0 hover:bg-slate-800/50">
                                    {row.map((cell, cellIndex) => (
                                        <td key={cellIndex} className="px-4 py-3 whitespace-nowrap">
                                            {cell}
                                        </td>
                                    ))}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {csvRows.length === 0 && (
                        <p className="text-center text-slate-500 py-4">No data rows found in this file.</p>
                    )}
                </div>
            </div>
        )}

        {status === UploadStatus.FILE_SELECTED && (
            <div className="mt-6 text-right">
                <button
                    onClick={handleUpload}
                    disabled={!file}
                    className="w-full sm:w-auto bg-sky-600 text-white font-bold py-3 px-8 rounded-lg hover:bg-sky-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    Upload {team.name} Report
                </button>
            </div>
        )}
    </div>
  );
};

export default FileUploadCard;